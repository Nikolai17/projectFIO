//
//  ThreeViewController.swift
//  test_project2
//
//  Created by macOS on 14.05.19.
//  Copyright © 2019 macOS. All rights reserved.
//

import UIKit



class ThreeViewController: UIViewController
{



   
   @IBOutlet weak var label1: UILabel!
    
   let picker = UIDatePicker()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        picker.center=view.center
        self.view.addSubview(picker)
        picker.addTarget(self, action: #selector(dataChanged), for: .valueChanged)
        
        picker.datePickerMode = .date
        
    }
    
    @objc func dataChanged()
    {
    
    Getform()
    }
  
    func Getform()
    {
      let formatter=DateFormatter()
        formatter.dateFormat="dd.MM.yyyy"
        label1.text=formatter.string(from: picker.date)
    
    }
    
    
}
